package com.qualcomm.ftcrobotcontroller.opmodes.Autonomous;

import com.qualcomm.ftcrobotcontroller.opmodes.MyOpMode;

/**
 * Created by User on 1/21/2016.
 */
public class Climbers extends MyOpMode {
    @Override
    public void runOpMode() throws InterruptedException {

        telemetry.addData("Sensors", "Misconfigured");

        mapObjects();
        initServos();

        initSensors();

        telemetry.addData("Robot", "init");
        waitForStart();


        moveTo(.4, 275);
        slowTurn(.4, 57);
        moveTo(.4, 5000);
        untilWhite(.3);
        //moveTo(.4, 140);
        arcTurn(.4, 38);
        moveTo(.4, 215, 1, 3, 3);
        //correct(.15);
        dumpHook();
    }
}
