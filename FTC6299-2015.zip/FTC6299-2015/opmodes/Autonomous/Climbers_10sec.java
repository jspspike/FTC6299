package com.qualcomm.ftcrobotcontroller.opmodes.Autonomous;

import com.qualcomm.ftcrobotcontroller.opmodes.MyOpMode;

/**
 * Created by User on 1/21/2016.
 */
public class Climbers_10sec extends MyOpMode {
    @Override
    public void runOpMode() throws InterruptedException {

        telemetry.addData("Robot", "Initialized");
        mapObjects();
        initServos();
        telemetry.addData("Sensors", "Misconfigured");
        initSensors();
        waitForStart();

        simpleWait(10000);
        moveTo(.4, 275);
        slowTurn(.4, 55);
        moveTo(.4, 5000);
        untilWhite(.3);
        moveTo(.4, 140);
        slowTurn(.4, 40);
        moveTo(.4, 600, 1, 3, 3);
        //correct(.15);
        dumpHook();
    }
}