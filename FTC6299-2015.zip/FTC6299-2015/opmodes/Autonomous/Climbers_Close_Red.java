package com.qualcomm.ftcrobotcontroller.opmodes.Autonomous;

import com.qualcomm.ftcrobotcontroller.opmodes.MyOpMode;

/**
 * Created by User on 4/18/2016.
 */
public class Climbers_Close_Red extends MyOpMode {
    @Override
    public void runOpMode() throws InterruptedException {
        telemetry.addData("Sensors", "Misconfigured");

        mapObjects();
        initServos();
        initSensors();

        telemetry.addData("Robot", "init");
        waitForStart();

        moveTo(.4, 275);
        slowTurn(.4, -47);
        moveTo(.4, 3500);
        untilWhite(.3);
        //moveTo(.4, 140);
        arcTurn(.4, -48);
        moveTo(.4, 215, 1, 3, 3);
        //correct(.15);
        dumpHook();
    }
}
