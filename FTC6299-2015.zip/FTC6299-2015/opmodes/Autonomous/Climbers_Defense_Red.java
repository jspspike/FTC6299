package com.qualcomm.ftcrobotcontroller.opmodes.Autonomous;

import com.qualcomm.ftcrobotcontroller.opmodes.MyOpMode;

/**
 * Created by User on 3/1/2016.
 */
public class Climbers_Defense_Red extends MyOpMode {
    @Override
    public void runOpMode() throws InterruptedException {
        telemetry.addData("Robot", "Initialized");
        mapObjects();
        initServos();
        telemetry.addData("Sensors", "Misconfigured");
        initSensors();
        waitForStart();

        moveTo(.4, 275);
        slowTurn(.4, -55);
        moveTo(.4, 5000);
        untilWhite(.3);
        //moveTo(.4, 140);
        arcTurn(.4, -40);
        moveTo(.4, 215, 1, 3, 3);
        //correct(.15);
        dumpHook();
        moveTo(-.4, 700);
        slowTurn(.4, -60);
        moveTo(-.4, 3000);
        telemetry.addData("Robot", "Stop");
    }
}
