package com.qualcomm.ftcrobotcontroller.opmodes.Autonomous;

import com.qualcomm.ftcrobotcontroller.opmodes.MyOpMode;


public class GyroColor extends MyOpMode {
    @Override
    public void runOpMode() throws InterruptedException {

        telemetry.addData("Robot", "Initialized");
        mapObjects();
        initServos();
        telemetry.addData("Sensors", "Misconfigured");
        initSensors();

        waitForStart();
        resetGyro();

        while (opModeIsActive()) {
            telemetry.addData("Gyro", getGyroYaw());
            telemetry.addData("Color", sensorRGB.blue());
            waitForStart();
        }
    }
}
