package com.qualcomm.ftcrobotcontroller.opmodes.Autonomous;

import com.qualcomm.ftcrobotcontroller.opmodes.MyOpMode;

/**
 * Created by User on 1/19/2016.
 */
public class Park_Red extends MyOpMode {

    @Override
    public void runOpMode() throws InterruptedException {
        mapObjects();
        initServos();
        resetEncoders();
        telemetry.addData("Current", "init");

        waitForStart();

        //simpleWait(9000);
        simpleMoveTo(.5, 6790, 10000);

        simpleTurn(.3, -150, 10000);
        dumpHook();
        telemetry.addData("Current", "Stop");
    }
}
