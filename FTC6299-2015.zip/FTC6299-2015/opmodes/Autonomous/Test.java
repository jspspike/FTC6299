package com.qualcomm.ftcrobotcontroller.opmodes.Autonomous;

import com.qualcomm.ftcrobotcontroller.opmodes.MyOpMode;
import com.qualcomm.robotcore.eventloop.opmode.OpMode;

/**
 * Created by User on 1/21/2016.
 */
public class Test extends MyOpMode {
    @Override
    public void runOpMode() throws InterruptedException {
        telemetry.addData("Init", "!");
        mapObjects();
        resetEncoders();
        waitForStart();
        telemetry.addData("Running", "!");

        while(opModeIsActive()) {
            telemetry.addData("Average", getEncoderAvg());
            telemetry.addData("FL Encoder", motorFL.getCurrentPosition());
            telemetry.addData("FR Encoder", motorFR.getCurrentPosition());
            telemetry.addData("BL Encoder", motorBL.getCurrentPosition());
            telemetry.addData("BR Encoder", motorBR.getCurrentPosition());
            telemetry.addData("LiftL", liftL.getCurrentPosition());
            telemetry.addData("LiftR", liftR.getCurrentPosition());
        }
        setMotors(0,0);
    }
}