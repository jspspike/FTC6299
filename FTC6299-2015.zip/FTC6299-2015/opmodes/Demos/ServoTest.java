package com.qualcomm.ftcrobotcontroller.opmodes.Demos;

import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.hardware.Servo;

/**
 * Created by User on 3/24/2016.
 */
public class ServoTest extends LinearOpMode {
    @Override
    public void runOpMode() throws InterruptedException {

        Servo servo = hardwareMap.servo.get("beltL");
        Servo servo2 = hardwareMap.servo.get("beltR");

        waitForStart();
        while (opModeIsActive()) {
            servo.setPosition(1);
            servo2.setPosition(1);
        }

    }
}
