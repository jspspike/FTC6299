package com.qualcomm.ftcrobotcontroller.opmodes.Demos;

import com.qualcomm.hardware.adafruit.AdafruitI2cColorSensor;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.hardware.ColorSensor;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DeviceInterfaceModule;
import com.qualcomm.robotcore.hardware.DigitalChannelController;

/**
 * Created by User on 4/4/2016.
 */
public class TrollBot extends LinearOpMode{
    DeviceInterfaceModule cdim;
    ColorSensor sensorRGB;
    static final int LED_CHANNEL = 5;

    DcMotor motorBL;
    DcMotor motorFL;
    DcMotor motorFR;
    DcMotor motorBR;

    @Override
    public void runOpMode() throws InterruptedException {
        hardwareMap.logDevices();

        motorBL = hardwareMap.dcMotor.get("motorBL");
        motorBR = hardwareMap.dcMotor.get("motorBR");
        motorFL = hardwareMap.dcMotor.get("motorFL");
        motorFR = hardwareMap.dcMotor.get("motorFR");


        // get a reference to our ColorSensor object.
        sensorRGB = hardwareMap.colorSensor.get("mr");

        // bEnabled represents the state of the LED.
        sensorRGB.enableLed(true);

        // turn the LED on in the beginning, just so user will know that the sensor is active.

        // wait one cycle.
        waitOneFullHardwareCycle();

        // wait for the start button to be pressed.
        waitForStart();

        while(sensorRGB.alpha() < 20 && opModeIsActive()) {

            motorBL.setPower(-.1);
            motorFL.setPower(-.1);
            motorFR.setPower(.1);
            motorBR.setPower(.1);
            telemetry.addData("Clear", sensorRGB.alpha());
            telemetry.addData("Red  ", sensorRGB.red());
            telemetry.addData("Green", sensorRGB.green());
            telemetry.addData("Blue ", sensorRGB.blue());

            waitOneFullHardwareCycle();
        }


        telemetry.addData("Clear", sensorRGB.alpha());
        telemetry.addData("Red  ", sensorRGB.red());
        telemetry.addData("Green", sensorRGB.green());
        telemetry.addData("Blue ", sensorRGB.blue());
        telemetry.addData("Robot", "Stop");

        motorBL.setPower(0);
        motorBR.setPower(0);
        motorFL.setPower(0);
        motorFR.setPower(0);
    }
}
