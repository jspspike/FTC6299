/* Copyright (c) 2014, 2015 Qualcomm Technologies Inc

All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted (subject to the limitations in the disclaimer below) provided that
the following conditions are met:

Redistributions of source code must retain the above copyright notice, this list
of conditions and the following disclaimer.

Redistributions in binary form must reproduce the above copyright notice, this
list of conditions and the following disclaimer in the documentation and/or
other materials provided with the distribution.

Neither the name of Qualcomm Technologies Inc nor the names of its contributors
may be used to endorse or promote products derived from this software without
specific prior written permission.

NO EXPRESS OR IMPLIED LICENSES TO ANY PARTY'S PATENT RIGHTS ARE GRANTED BY THIS
LICENSE. THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. */

package com.qualcomm.ftcrobotcontroller.opmodes;

import com.qualcomm.ftcrobotcontroller.opmodes.Autonomous.Climbers_Close;
import com.qualcomm.ftcrobotcontroller.opmodes.Autonomous.Climbers_Close_Red;
import com.qualcomm.ftcrobotcontroller.opmodes.Demos.MRRGBExample;
import com.qualcomm.ftcrobotcontroller.opmodes.Demos.TrollBot;
import com.qualcomm.ftcrobotcontroller.opmodes.Autonomous.Climbers;
import com.qualcomm.ftcrobotcontroller.opmodes.Autonomous.Climbers_10sec;
import com.qualcomm.ftcrobotcontroller.opmodes.Autonomous.Climbers_Defense;
import com.qualcomm.ftcrobotcontroller.opmodes.Autonomous.Climbers_Defense_Red;
import com.qualcomm.ftcrobotcontroller.opmodes.Autonomous.Climbers_Red;
import com.qualcomm.ftcrobotcontroller.opmodes.Autonomous.Climbers_Red_10sec;
import com.qualcomm.ftcrobotcontroller.opmodes.Autonomous.GyroColor;
import com.qualcomm.ftcrobotcontroller.opmodes.Autonomous.IMUtest;
import com.qualcomm.ftcrobotcontroller.opmodes.Autonomous.Park;
import com.qualcomm.ftcrobotcontroller.opmodes.Autonomous.Park_Red;
import com.qualcomm.ftcrobotcontroller.opmodes.Autonomous.Test;
import com.qualcomm.ftcrobotcontroller.opmodes.Demos.AdafruitRGBExample;
import com.qualcomm.ftcrobotcontroller.opmodes.Demos.MRGyroTest;
import com.qualcomm.ftcrobotcontroller.opmodes.Demos.ServoTest;
import com.qualcomm.ftcrobotcontroller.opmodes.Teleop.LittleLeague;
import com.qualcomm.robotcore.eventloop.opmode.OpModeManager;
import com.qualcomm.robotcore.eventloop.opmode.OpModeRegister;

/**
 * Register Op Modes
 */
public class FtcOpModeRegister implements OpModeRegister {

  /**
   * The Op Mode Manager will call this method when it wants a list of all
   * available op modes. Add your op mode to the list to enable it.
   *
   * @param manager op mode manager
   */
  public void register(OpModeManager manager) {
      manager.register("Little League", LittleLeague.class);

      manager.register("Climber Blue", Climbers.class);
      manager.register("Climber Red", Climbers_Red.class);
      manager.register("Climber Close Blue", Climbers_Close.class);
      manager.register("Climber Close Red", Climbers_Close_Red.class);
      manager.register("Climbers Defensive Blue", Climbers_Defense.class);
      manager.register("Climbers Defensive Red", Climbers_Defense_Red.class);
      manager.register("Climber Blue (10sec)", Climbers_10sec.class);
      manager.register("Climber Red (10sec)", Climbers_Red_10sec.class);


      manager.register("Encoder Move Test", Park.class);
      manager.register("Econder Test", Test.class);

      manager.register("Gyro and Color", GyroColor.class);
      manager.register("Gyro Test", IMUtest.class);

      manager.register("Color", MRRGBExample.class);
      manager.register("Servo", ServoTest.class);

      manager.register("TrollBot", TrollBot.class);
  }
}
