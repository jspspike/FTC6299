package com.qualcomm.ftcrobotcontroller.opmodes.Teleop;

import com.qualcomm.robotcore.eventloop.opmode.OpMode;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.Servo;

/**
 * Created by jspspike on 11/14/15.
 */
public class BasicTeleop extends OpMode {
    DcMotor motorBL;
    DcMotor motorBR;
    DcMotor motorFL;
    DcMotor motorFR;

    Servo clawL;
    Servo clawR;

    @Override
    public void init(){
        motorBL = hardwareMap.dcMotor.get("motorBL");
        motorBR = hardwareMap.dcMotor.get("motorBR");
        motorFL = hardwareMap.dcMotor.get("motorFL");
        motorFR = hardwareMap.dcMotor.get("motorFR");

        clawL = hardwareMap.servo.get("clawL");
        clawR = hardwareMap.servo.get("clawR");
    }

    @Override
    public void loop() {
        if (Math.abs(gamepad1.left_stick_y) > .07 || Math.abs(gamepad1.right_stick_y) > .07) {
            motorBR.setPower(-gamepad1.right_stick_y);
            motorFR.setPower(-gamepad1.right_stick_y);
            motorBL.setPower(gamepad1.left_stick_y);
            motorFL.setPower(gamepad1.left_stick_y);
        }

        else {
            motorBR.setPower(0);
            motorFR.setPower(0);
            motorBL.setPower(0);
            motorFL.setPower(0);
        }

        if (gamepad1.a) {
            clawL.setPosition(0);
            clawR.setPosition(1);
        }

        else if (gamepad1.x) {
            clawL.setPosition(1);
            clawR.setPosition(0);
        }
    }
}
