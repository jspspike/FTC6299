package com.qualcomm.ftcrobotcontroller.opmodes.Teleop;

import com.qualcomm.ftcrobotcontroller.opmodes.Autonomous.Park;
import com.qualcomm.ftcrobotcontroller.opmodes.MyOpMode;


//Created by FTC6299

public class LittleLeague extends MyOpMode {

    boolean modify = true;
    boolean ratchets = false;


    @Override
    public void runOpMode() throws InterruptedException {
        mapObjects();
        initServos();
        resetEncoders();
        //initSensors();
        telemetry.addData("Robot", "init");
        waitForStart();

        double base_x1;
        double base_y1;
        double base_x2;
        double base_y2;
        double lift_x1;
        double lift_y1;
        double lift_x2;
        double lift_y2;



        while (opModeIsActive()) {

//            telemetry.addData("ColorAlpha", sensorRGB.alpha());
//            telemetry.addData("ColorRed", sensorRGB.red());
//            telemetry.addData("ColorBlue", sensorRGB.blue());
//            telemetry.addData("ColorGreen", sensorRGB.green());

            base_x1 = gamepad1.left_stick_x;
            base_y1 = gamepad1.left_stick_y;
            base_x2 = gamepad1.right_stick_x;
            base_y2 = gamepad1.right_stick_y;
            lift_x1 = gamepad2.left_stick_x;
            lift_y1 = gamepad2.left_stick_y;
            lift_x2 = gamepad2.right_stick_x;
            lift_y2 = gamepad2.right_stick_y;

            //Base Motor Control
            if ((Math.abs(base_y1) > .07 || Math.abs(base_y2) > .07) && modify) {
                motorBL.setPower(base_y1);
                motorFL.setPower(base_y1);
                motorFR.setPower(base_y2 * -1);
                motorBR.setPower(base_y2 * -1);
            }

            else if ((Math.abs(base_y1) > .07 || Math.abs(base_y2) > .07) && !modify) {
                motorBL.setPower(base_y2 * -1);
                motorFL.setPower(base_y2 * -1);
                motorFR.setPower(base_y1);
                motorBR.setPower(base_y1);
            }

            else {
                motorBL.setPower(0);
                motorFL.setPower(0);
                motorFR.setPower(0);
                motorBR.setPower(0);
            }

            //Manipulator Control
            if (gamepad1.left_trigger > .5) {
                manip.setPower(1);
            }

            else if (gamepad1.right_trigger > .5) {
                manip.setPower(-1);
            }

            else {
                manip.setPower(0);
            }



            //Drive Direction Control
            if (gamepad1.a) {
                modify = true;
            }

            else if (gamepad1.x) {
                modify = false;
            }

            //Servo Claw Control
            if (gamepad1.left_bumper) {
                setClawsDown(false);
            }

            else if (gamepad1.right_bumper) {
                setClawsDown(true);
            }

            if (gamepad1.dpad_left) {
                try {
                    clawL.setPosition(clawL.getPosition() - .01);
                    clawR.setPosition(clawR.getPosition() + .01);
                }

                catch (Exception e) {
                    telemetry.addData("Claw out of Bounds!", e);
                }
            }

            else if (gamepad1.dpad_right) {
                try {
                    clawL.setPosition(clawL.getPosition() + .01);
                    clawR.setPosition(clawR.getPosition() - .01);
                }

                catch (Exception e) {
                    telemetry.addData("Claw out of bounds!", e);
                }
            }
            telemetry.addData("clawL: ", clawL.getPosition());
            telemetry.addData("clawR: ", clawR.getPosition());



            //Rack and Pinion
            if (gamepad1.b) {
                rack.setPosition(1);
            }

            else if (gamepad1.y) {
                rack.setPosition(0);
            }

            else {
                rack.setPosition(.5);
            }



            //Lift Control

            if (lift_y1 > .07 && lift_x2 > .3) {
                liftL.setPower(lift_y1 * .45);
                liftR.setPower(-lift_y1 * .45);
                beltL.setPosition(BELTL_SPEED_RIGHT * Math.abs(lift_x2));
                beltR.setPosition(BELTR_SPEED_RIGHT * Math.abs(lift_x2));
            }

            else if (lift_y1 < - .07 && lift_x2 > .3) {
                liftL.setPower(-Math.pow(lift_y1, 2));
                liftR.setPower(Math.pow(lift_y1, 2));
                beltL.setPosition(BELTL_SPEED_RIGHT * Math.abs(lift_x2));
                beltR.setPosition(BELTR_SPEED_RIGHT * Math.abs(lift_x2));
            }

            else if (lift_y1 > .07 && lift_x2 < -.3) {
                liftL.setPower(lift_y1 * .45);
                liftR.setPower(-lift_y1 * .45);
                beltL.setPosition(BELTL_SPEED_LEFT * Math.abs(lift_x2));
                beltR.setPosition(BELTR_SPEED_LEFT * Math.abs(lift_x2));
            }

            else if (lift_y1 < - .07 && lift_x2 < -.3) {
                liftL.setPower(-Math.pow(lift_y1, 2));
                liftR.setPower(Math.pow(lift_y1, 2));
                beltL.setPosition(BELTL_SPEED_LEFT * Math.abs(lift_x2));
                beltR.setPosition(BELTR_SPEED_LEFT * Math.abs(lift_x2));
            }

            else if (lift_y1 < -.07 && gamepad1.dpad_up) {
                liftL.setPower(Math.pow(lift_y1, 2));
                liftR.setPower(-Math.pow(lift_y1, 2));
                winch.setPower(-1);
            }

            else if (lift_y1 < -.07 && gamepad1.dpad_down) {
                liftL.setPower(-Math.pow(lift_y1, 2));
                liftR.setPower(Math.pow(lift_y1, 2));
                winch.setPower(1);
            }

            else if (lift_y1 > .07 && gamepad1.dpad_up) {
                liftL.setPower(lift_y1 * .45);
                liftR.setPower(-lift_y1 * .45);
                winch.setPower(-1);
            }

            else if (lift_y1 > .07 && gamepad1.dpad_down) {
                liftL.setPower(lift_y1 * .45);
                liftR.setPower(-lift_y1 * .45);
                winch.setPower(1);
            }

            else if (gamepad2.left_stick_button && gamepad2.right_stick_button) {
                beltL.setPosition(BELTL_SPEED_LEFT);
                beltR.setPosition(BELTR_SPEED_RIGHT);
            }

            else if (gamepad2.left_stick_button) {
                beltL.setPosition(BELTL_SPEED_LEFT);
            }

            else if (gamepad2.right_stick_button) {
                beltR.setPosition(BELTR_SPEED_RIGHT);
            }



            else if (lift_x2 > .3) {
                beltL.setPosition(BELTL_SPEED_RIGHT * Math.abs(lift_x2));
                beltR.setPosition(BELTR_SPEED_RIGHT * Math.abs(lift_x2));
                liftL.setPower(0);
                liftR.setPower(0);
            }

            else if (lift_x2 < -.3) {
                beltL.setPosition(BELTL_SPEED_LEFT * Math.abs(lift_x2));
                beltR.setPosition(BELTR_SPEED_LEFT * Math.abs(lift_x2));
                liftL.setPower(0);
                liftR.setPower(0);
            }

            else if (gamepad1.dpad_up) {
                winch.setPower(-1);
            }

            else if (gamepad1.dpad_down) {
                winch.setPower(1);
            }

            else if (gamepad2.left_stick_y < -.07) {
                liftL.setPower(lift_y1);
                liftR.setPower(-lift_y1);
                beltL.setPosition(.5);
                beltR.setPosition(.5);
            }

            else if (gamepad2.left_stick_y > .07) {
                liftL.setPower(lift_y1 * .3);
                liftR.setPower(-lift_y1 * .3);
                beltL.setPosition(.5);
                beltR.setPosition(.5);
            }

            else if (Math.abs(lift_y2) > .07) {
                winch.setPower(lift_y2);
            }

            else if (gamepad2.left_stick_x > .7) {
                liftR.setPower(0);
                liftL.setPower(Math.abs(lift_x1));
            }

            else if (gamepad2.left_stick_x < -.7) {
                liftR.setPower(Math.abs(lift_x1) * -1);
                liftL.setPower(0);
            }

            else {
                winch.setPower(0);
                liftL.setPower(0);
                liftR.setPower(0);
                beltL.setPosition(.5);
                beltR.setPosition(.5);
            }

            //Servo Basket Control
            if (gamepad2.b && gamepad2.right_bumper) {
                while (gamepad2.b && gamepad2.right_bumper){
                    basket.setPosition(basket.getPosition() - .06);
                    simpleWait(50);
                    basket.setPosition(basket.getPosition() + .06);
                    simpleWait(50);
                }
            }

            else if (gamepad2.x && gamepad2.left_bumper) {
                while (gamepad2.x && gamepad2.left_bumper){
                    basket.setPosition(basket.getPosition() + .06);
                    simpleWait(50);
                    basket.setPosition(basket.getPosition() - .06);
                    simpleWait(50);
                }
            }

            else if (gamepad2.a) {
                setBasket('a');
            }

            else if (gamepad2.b) {
                setBasket('b');
            }

            else if (gamepad2.x) {
                setBasket('x');
            }

            telemetry.addData("Basket", basket.getPosition());

            if (gamepad2.left_bumper && gamepad2.left_trigger > .7) {
                setDoorL(2);
                Thread.sleep(100);
            }

            else if (gamepad2.right_bumper && gamepad2.right_trigger > .7) {
                setDoorR(2);
                Thread.sleep(100);
            }

            else if (gamepad2.left_bumper) {
                setDoorL(0);
            }

            else if (gamepad2.left_trigger > .7) {
                setDoorL(1);
            }

            else if (gamepad2.right_bumper) {
                setDoorR(0);
            }

            else if (gamepad2.right_trigger > .7) {
                setDoorR(1);
            }

            if (gamepad2.dpad_left) {
                try {
                    basket.setPosition(basket.getPosition() - .02);
                    Thread.sleep(100);
                }

                catch (Exception e) {
                    telemetry.addData("OutofBounds!", e);
                }
            }

            if (gamepad2.dpad_right) {
                try {
                    basket.setPosition(basket.getPosition() + .02);
                    Thread.sleep(100);
                }

                catch (Exception e) {
                    telemetry.addData("OutofBounds!", e);
                }
            }



            //Ratchet Control
            if (gamepad2.start && !ratchets) {
                setRatchet(true);
                ratchets = true;
                try {
                    Thread.sleep(400);
                }

                catch(Exception e) {
                    telemetry.addData("Thread.sleep failure!", e);
                }
            }

            else if (gamepad2.start && ratchets) {
                setRatchet(false);
                ratchets = false;
                try {
                    Thread.sleep(400);
                }

                catch(Exception e) {
                    telemetry.addData("Thread.sleep failure!", e);
                }
            }

            //Hook control
            if (gamepad2.dpad_up) {
                setHook(true);
            } else if (gamepad2.dpad_down) {
                setHook(false);
            }

            else {
                hook.setPosition(.5);
            }
            waitOneFullHardwareCycle();
        }
        setRatchet(true);
    }
}