package com.qualcomm.ftcrobotcontroller.opmodes.Teleop;

import com.qualcomm.robotcore.eventloop.opmode.OpMode;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.Servo;

/**
 * Created by User on 1/12/2016.
 */
public class ServoTest extends OpMode{
    DcMotor motorBL;
    DcMotor motorBR;
    DcMotor motorFL;
    DcMotor motorFR;

    DcMotor liftL;
    DcMotor liftR;

    DcMotor manip;
    DcMotor winch;

    Servo clawL;
    Servo clawR;

    Servo basket;
    Servo doorL;
    Servo doorR;

    Servo hook;

    Servo rack;

    Servo ratchet;

    public void init() {
        motorBL = hardwareMap.dcMotor.get("motorBL");
        motorBR = hardwareMap.dcMotor.get("motorBR");
        motorFL = hardwareMap.dcMotor.get("motorFL");
        motorFR = hardwareMap.dcMotor.get("motorFR");
        winch = hardwareMap.dcMotor.get("winch");

        manip = hardwareMap.dcMotor.get("manip");

        clawL = hardwareMap.servo.get("clawL");
        clawR = hardwareMap.servo.get("clawR");

        liftL = hardwareMap.dcMotor.get("liftL");
        liftR = hardwareMap.dcMotor.get("liftR");

        basket = hardwareMap.servo.get("basket");
        doorL = hardwareMap.servo.get("doorL");
        doorR = hardwareMap.servo.get("doorR");

        hook = hardwareMap.servo.get("hook");

        rack = hardwareMap.servo.get("rack");
        ratchet = hardwareMap.servo.get("ratchet");
        basket.setPosition(.5);

    }

    public void loop() {
        basket.setPosition(1);
//        clawL.setPosition(1);
//        clawR.setPosition(1);
        hook.setPosition(1);
    }
}
