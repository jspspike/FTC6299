package com.qualcomm.ftcrobotcontroller.opmodes.helperBuffers_4211Libs;

import com.qualcomm.robotcore.hardware.HardwareMap;

/**
 * Created by FTC Robot Team 4211 on 7/31/2015.
 */
public abstract class BufferSupportedRunnable implements Runnable, physicalDataListener {
    public BufferedDeviceManager bufferedDeviceManager;
    public HardwareMap hMap;
    
    public BufferSupportedRunnable(HardwareMap map) {
        bufferedDeviceManager = new BufferedDeviceManager();
        bufferedDeviceManager.addPhysicalDataListener(this);
        hMap = map;
    }
    
    @Override
    public void newDataReceived() {
        try {
            this.notifyAll();
        } catch (IllegalMonitorStateException e) {
            e.printStackTrace();
        }
    }

    public void newDataWait(long waitTimeMs) {
        try {
            this.wait(waitTimeMs);
        } catch(InterruptedException e) {
            e.printStackTrace();
        }
    }

    public void simpleWait(long waitTimeMs) {
        try {
            Thread.sleep(waitTimeMs);
        } catch(InterruptedException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void run() {

    }
}
